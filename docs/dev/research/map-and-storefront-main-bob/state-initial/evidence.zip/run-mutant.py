import json
import os
import subprocess
import sys
from pathlib import Path

REPORT = Path('/tmp/worldmock-map-main-bob-state-8RnVvy')
PLAN = json.loads((REPORT / 'predeclared-mutants.json').read_text()) + json.loads((REPORT / 'predeclared-additional-mutant.json').read_text())
TREE = Path(PLAN[0]['cwd'])
PYTHON = PLAN[0]['command'][0]
ENV = dict(os.environ, **PLAN[0]['environment'])
NAME = sys.argv[1]
ITEM = next(item for item in PLAN if item['name'] == NAME)


def record(suffix, command):
    result = subprocess.run(command, cwd=TREE, env=ENV, text=True, capture_output=True)
    stem = REPORT / (NAME + '-' + suffix)
    stem.with_suffix('.stdout').write_text(result.stdout)
    stem.with_suffix('.stderr').write_text(result.stderr)
    stem.with_suffix('.exit').write_text(str(result.returncode) + '\n')
    stem.with_suffix('.command.json').write_text(json.dumps(command) + '\n')
    print(NAME, suffix, result.returncode, result.stdout[-1400:].strip(), flush=True)
    return result


def clean(phase):
    diff = record(phase + '-diff', ['git', 'diff', '--exit-code'])
    status = record(phase + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
    if diff.returncode or status.returncode or status.stdout:
        raise RuntimeError('Temporary tree is not clean')


clean('before')
source = TREE / ITEM['path']
original = source.read_text()
if NAME == 'decision_visible_cache_early_clear':
    old = '        events = commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_presentation = None\n        self._pending_visible_supplies = {}'
    new = '        self._pending_visible_supplies = {}\n        events = commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_presentation = None'
elif NAME == 'advance_presentation_cache_early_clear':
    old = '        commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_presentation = None\n        self._pending_visible_supplies = {}'
    new = '        self._pending_presentation = None\n        commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_visible_supplies = {}'
elif NAME == 'advance_success_keeps_stale_presentation_cache':
    old = '        commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_presentation = None\n        self._pending_visible_supplies = {}'
    new = '        commit_state(self.store, staged, drafts)\n        self.state = staged\n        self._pending_visible_supplies = {}'
elif NAME == 'missing_category_version_is_accepted':
    old = '    expected = category_identity(semantics)\n'
    new = '    expected = category_identity(semantics)\n    expected.pop("category_contract_version")\n'
elif NAME == 'map_supply_hash_is_not_compared':
    old = '    if manifest.get("map_dataset") != map_provenance(scenario):\n'
    new = ('    if {key: value for key, value in manifest.get("map_dataset", {}).items() if key != "supplies_file"} != (\n'
           '            {key: value for key, value in map_provenance(scenario).items() if key != "supplies_file"}):\n')
else:
    raise RuntimeError('Unknown predeclared mutant')
if original.count(old) != 1:
    raise RuntimeError('Mutation must match exactly one source location')
source.write_text(original.replace(old, new, 1))
try:
    patch = record('patch', ['git', 'diff', '--', ITEM['path']])
    (REPORT / (NAME + '.patch')).write_text(patch.stdout)
    code = ('import importlib, pathlib; root = pathlib.Path(' + repr(str(TREE)) + ').resolve(); '
            'module = importlib.import_module(' + repr(ITEM['module']) + '); '
            'loaded = pathlib.Path(module.__file__).resolve(); print(loaded); '
            'assert loaded.is_relative_to(root); compile(loaded.read_text(), str(loaded), "exec")')
    imported = record('import-identity', [PYTHON, '-B', '-c', code])
    if imported.returncode:
        raise RuntimeError('Mutant import failed; invalid, not killed')
    result = record('oracle', ITEM['command'])
    (REPORT / (NAME + '-result.json')).write_text(json.dumps({
        'name': NAME, 'exit': result.returncode,
        'import_verified': True, 'classification': 'pending causal review'}, indent=2) + '\n')
finally:
    restored = record('restore', ['git', 'restore', '--source=70af9a70f82ebe9b2b33d5f4d7327f59de150002', '--worktree', '--', ITEM['path']])
    if restored.returncode:
        raise RuntimeError('Restoration failed; stop all further mutation')
    clean('after-restore')
