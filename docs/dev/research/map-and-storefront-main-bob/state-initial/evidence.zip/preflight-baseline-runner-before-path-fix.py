import json
import os
import subprocess
import sys
from pathlib import Path

REPORT = Path('/tmp/worldmock-map-main-bob-state-8RnVvy')
PLAN = json.loads((REPORT / 'predeclared-mutants.json').read_text())
TREE = Path(PLAN[0]['cwd'])
PYTHON = PLAN[0]['command'][0]
ENV = dict(os.environ, **PLAN[0]['environment'])

def record(name, command):
    result = subprocess.run(command, cwd=TREE, env=ENV, text=True, capture_output=True)
    (REPORT / (name + '.stdout')).write_text(result.stdout)
    (REPORT / (name + '.stderr')).write_text(result.stderr)
    (REPORT / (name + '.exit')).write_text(str(result.returncode) + '\n')
    (REPORT / (name + '.command.json')).write_text(json.dumps(command) + '\n')
    print(name, result.returncode, result.stdout[-700:].strip(), flush=True)
    return result

modules = sorted({item['module'] for item in PLAN})
code = "import importlib, pathlib; root = pathlib.Path(" + repr(str(TREE)) + "); "
code += "modules = " + repr(modules) + "; "
code += "loaded = {name: pathlib.Path(importlib.import_module(name).__file__).resolve() for name in modules}; "
code += "print('\\n'.join(f'{name}: {path}' for name, path in loaded.items())); "
code += "assert all(path.is_relative_to(root) for path in loaded.values())"
if record('baseline-import-identity', [PYTHON, '-B', '-c', code]).returncode:
    sys.exit('Baseline import identity failed')
for item in PLAN:
    result = record('baseline-' + item['name'], item['command'])
    if result.returncode or '1 passed' not in result.stdout or 'skipped' in result.stdout:
        sys.exit('Baseline must pass exactly one existing test without skips')
if record('baseline-clean-diff', ['git', 'diff', '--exit-code']).returncode:
    sys.exit('Baseline changed tracked files')
status = record('baseline-clean-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
if status.returncode or status.stdout:
    sys.exit('Baseline produced untracked source artifacts')
