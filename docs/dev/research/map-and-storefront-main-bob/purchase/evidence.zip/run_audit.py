import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('/tmp/worldmock-map-main-bob-purchase-G4Tavc')
TREE = Path('/tmp/worldmock-map-main-bob-purchase-tree-mYw48O')
CALLER = Path('/Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock')
PYTHON = CALLER / '.venv/bin/python'
PLAN = json.loads((ROOT / 'plan.json').read_text())
ENV = os.environ.copy()
ENV.update(PYTHONPATH=str(TREE / 'src') + ':' + str(TREE), LITELLM_LOCAL_MODEL_COST_MAP='True', AGENTSOCIETY_LLM_API_KEY='test-only', PYTHONDONTWRITEBYTECODE='1')

def run(label, argv, cwd=TREE):
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, env=ENV, capture_output=True, text=True)
    (ROOT / (label + '.stdout')).write_text(result.stdout)
    (ROOT / (label + '.stderr')).write_text(result.stderr)
    record = {'argv': [str(arg) for arg in argv], 'cwd':str(cwd), 'returncode':result.returncode, 'started_at':start, 'ended_at':datetime.now(timezone.utc).isoformat()}
    (ROOT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    return result

def clean(label):
    diff = run(label + '-diff', ['git','diff','--exit-code'])
    staged = run(label + '-cached-diff', ['git','diff','--cached','--exit-code'])
    status = run(label + '-status', ['git','status','--porcelain=v1','--untracked-files=all'])
    assert diff.returncode == staged.returncode == status.returncode == 0
    assert not status.stdout, status.stdout

def origins(label, modules):
    code = 'import importlib, json; from pathlib import Path; tree=Path(' + repr(str(TREE)) + ').resolve(); modules=' + repr(modules) + '; origins={name:str(Path(importlib.import_module(name).__file__).resolve()) for name in modules}; print(json.dumps(origins, indent=2)); assert all(Path(file).is_relative_to(tree) for file in origins.values())'
    result = run(label + '-imports', [str(PYTHON), '-c', code])
    assert result.returncode == 0, result.stdout + result.stderr

action = sys.argv[1]
if action == 'baseline':
    clean('baseline-before')
    origins('baseline', sorted({item['module'] for item in PLAN}))
    seen = {}
    for item in PLAN:
        signature = tuple(item['argv'])
        if signature not in seen:
            label = 'baseline-' + item['name']
            result = run(label, item['argv'])
            print(label, 'exit', result.returncode, result.stdout.strip().splitlines()[-1:], flush=True)
            assert result.returncode == 0, result.stdout + result.stderr
            assert 'skipped' not in result.stdout and 'xfailed' not in result.stdout
            seen[signature] = label
        item['baseline_label'] = seen[signature]
    (ROOT / 'baseline-map.json').write_text(json.dumps(PLAN, indent=2) + '\n')
    clean('baseline-after')
elif action == 'mutate':
    item = next(item for item in PLAN if item['name'] == sys.argv[2])
    assert (ROOT / 'baseline-map.json').exists()
    clean(item['name'] + '-before')
    source = TREE / item['path']
    text = source.read_text()
    assert text.count(item['old']) == 1
    source.write_text(text.replace(item['old'], item['new']))
    patch = run(item['name'] + '-patch', ['git','diff','--',item['path']])
    assert patch.returncode == 0 and patch.stdout
    (ROOT / (item['name'] + '.patch')).write_text(patch.stdout)
    origins(item['name'], [item['module']])
    result = run(item['name'] + '-test', item['argv'])
    print(result.stdout)
    print(result.stderr)
    print('Test return code:', result.returncode, flush=True)
elif action == 'restore':
    item = next(item for item in PLAN if item['name'] == sys.argv[2])
    result = run(item['name'] + '-restore', ['git','restore','--source=HEAD','--',item['path']])
    assert result.returncode == 0, result.stderr
    assert (TREE / item['path']).read_bytes() == (ROOT / 'baseline-source' / item['path']).read_bytes()
    clean(item['name'] + '-restored')
    print(item['name'], 'restored; diff, cached diff, and complete status empty.', flush=True)
else:
    raise ValueError(action)
