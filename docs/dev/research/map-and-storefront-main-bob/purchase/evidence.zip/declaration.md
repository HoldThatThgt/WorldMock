# Predeclared mutation oracles

Baseline commit: 70af9a70f82ebe9b2b33d5f4d7327f59de150002

All commands execute in /tmp/worldmock-map-main-bob-purchase-tree-mYw48O.

## rounded_unit_before_quantity

Round one unit first, then multiply quantity, rather than round the complete line once.

Clauses: docs/dev/SPEC-map-and-storefront.md:100, docs/dev/SPEC-category-contract.md:144

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_storefront_category_integration.py::test_independent_quotes_share_exact_category_arithmetic_in_real_engine --tb=short
```

## zero_price_omits_stock_debit

A defined zero coefficient purchase creates its order without reducing supplied stock.

Clauses: docs/dev/SPEC-map-and-storefront.md:73, docs/dev/SPEC-category-contract.md:150

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_storefront_category_integration.py::test_defined_zero_coefficient_purchase_fulfills_without_account_transfer --tb=short
```

## inactive_pairing_advertises_free_price

A known quote with a non-defined pairing advertises actual purchase amount zero instead of null.

Clauses: docs/dev/SPEC-map-and-storefront.md:71, docs/dev/SPEC-category-contract.md:148

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_storefront_discovery.py::test_no_effect_supply_remains_visible_without_a_purchase_amount --tb=short
```

## no_effect_inherits_purchase_permission

Ignore an explicit no_effect child pairing and allow the defined product ancestor purchase rule.

Clauses: docs/dev/SPEC-map-and-storefront.md:99, docs/dev/SPEC-category-contract.md:150

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q 'tests/life/test_storefront_category_integration.py::test_purchase_pairing_recheck_refuses_without_any_domain_state_change[no_effect]' tests/life/test_category_runtime.py::test_no_effect_purchase_loads_and_rejects_without_transfer --tb=short
```

## credit_other_supply_seller

Credit another valid storefront seller while keeping the selected order and inventory identity.

Clauses: docs/dev/SPEC-map-and-storefront.md:103, docs/dev/SPEC-category-contract.md:152

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_storefront_category_integration.py::test_independent_quotes_share_exact_category_arithmetic_in_real_engine --tb=short
```

## debit_other_supply_stock

Debit a different storefront supply of the same product instead of the selected supply.

Clauses: docs/dev/SPEC-map-and-storefront.md:103, docs/dev/SPEC-category-contract.md:158

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_storefront_category_integration.py::test_independent_quotes_share_exact_category_arithmetic_in_real_engine --tb=short
```

## motivation_uses_raw_quote

Judge affordability and candidate cost using the raw quote rather than the category-adjusted payable amount.

Clauses: docs/dev/SPEC-map-and-storefront.md:72, docs/dev/SPEC-category-contract.md:149

```sh
PYTHONPATH=/tmp/worldmock-map-main-bob-purchase-tree-mYw48O/src:/tmp/worldmock-map-main-bob-purchase-tree-mYw48O LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONDONTWRITEBYTECODE=1 /Users/atishoo/.codex/worktrees/map-and-storefront-main/WorldMock/.venv/bin/python -m pytest -q tests/life/test_motivation.py::test_food_affordability_uses_category_amount_instead_of_raw_quote --tb=short
```
