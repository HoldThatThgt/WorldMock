import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

REPORT = Path('/tmp/worldmock-map-main-bob-state-recheck-0BouKN')
PLAN = json.loads((REPORT / 'predeclared-recheck.json').read_text())
PREFLIGHT = json.loads((REPORT / 'preflight.json').read_text())
TREE = Path(PLAN['cwd'])
ENV = dict(os.environ, **PLAN['environment'])
NAME = sys.argv[1]


def record(suffix, command):
    result = subprocess.run(command, cwd=TREE, env=ENV, text=True, capture_output=True)
    stem = REPORT / (NAME + '-' + suffix)
    stem.with_suffix('.stdout').write_text(result.stdout)
    stem.with_suffix('.stderr').write_text(result.stderr)
    stem.with_suffix('.exit').write_text(str(result.returncode) + '\n')
    stem.with_suffix('.command.json').write_text(json.dumps(command) + '\n')
    print(NAME, suffix, result.returncode, result.stdout[-1500:].strip(), flush=True)
    return result


def clean(phase):
    diff = record(phase + '-diff', ['git', 'diff', '--exit-code'])
    status = record(phase + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
    if diff.returncode or status.returncode or status.stdout:
        raise RuntimeError('Temporary tree is not clean')


def imports():
    code = ('import importlib, pathlib; root = pathlib.Path(' + repr(str(TREE)) + ').resolve(); '
            'module = importlib.import_module(' + repr(PLAN['module']) + '); '
            'loaded = pathlib.Path(module.__file__).resolve(); print(loaded); '
            'assert loaded.is_relative_to(root); compile(loaded.read_text(), str(loaded), "exec")')
    if record('import-identity', [PLAN['command'][0], '-B', '-c', code]).returncode:
        raise RuntimeError('Import identity or compile check failed')


clean('before')
if NAME == 'baseline':
    imports()
    result = record('oracle', PLAN['command'])
    if result.returncode or '1 passed' not in result.stdout or 'skipped' in result.stdout:
        raise RuntimeError('Baseline failed; mutation is forbidden')
    clean('after')
    sys.exit(0)
if (REPORT / 'baseline-oracle.exit').read_text().strip() != '0':
    raise RuntimeError('Green baseline required')
item = next(item for item in PLAN['mutants'] if item['name'] == NAME)
source = TREE / PLAN['path']
original = source.read_text()
old = ('        commit_state(self.store, staged, drafts)\n'
       '        self.state = staged\n'
       '        self._pending_presentation = None\n'
       '        self._pending_visible_supplies = {}')
if NAME == 'advance_success_keeps_stale_presentation_cache':
    new = old.replace('        self._pending_presentation = None\n', '')
elif NAME == 'advance_success_keeps_stale_supply_cache':
    new = old.replace('\n        self._pending_visible_supplies = {}', '')
else:
    raise RuntimeError('Unknown predeclared mutation')
if original.count(old) != 1:
    raise RuntimeError('Mutation must match exactly one source location')
source.write_text(original.replace(old, new, 1))
try:
    patch = record('patch', ['git', 'diff', '--', PLAN['path']])
    patch_file = REPORT / (NAME + '.patch')
    patch_file.write_text(patch.stdout)
    if 'original_patch' in item:
        old_bytes = Path(item['original_patch']).read_bytes()
        identical = patch_file.read_bytes() == old_bytes
        (REPORT / 'original-patch-byte-comparison.json').write_text(json.dumps({
            'identical': identical, 'sha256_original': hashlib.sha256(old_bytes).hexdigest(),
            'sha256_recheck': hashlib.sha256(patch_file.read_bytes()).hexdigest()}, indent=2) + '\n')
        if not identical:
            raise RuntimeError('Original survivor patch must be byte-identical')
    imports()
    result = record('oracle', PLAN['command'])
    (REPORT / (NAME + '-result.json')).write_text(json.dumps({'name': NAME, 'exit': result.returncode,
        'classification': 'pending causal review'}, indent=2) + '\n')
finally:
    restore = record('restore', ['git', 'restore', '--source=' + PREFLIGHT['baseline_commit'], '--worktree', '--', PLAN['path']])
    if restore.returncode:
        raise RuntimeError('Failed restoration; stop')
    clean('after-restore')
