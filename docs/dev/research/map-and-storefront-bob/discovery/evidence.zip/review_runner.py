from __future__ import annotations
import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

ROOT = Path('/tmp/worldmock-map-bob-discovery-worktree.ihrV5l')
CALLER = Path('/Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock')
REPORT = Path('/tmp/worldmock-map-bob-discovery')
PYTHON = str(CALLER / '.venv/bin/python')
COMMIT = '2bce358a09046b84841bc5a2da68d82a66b79dbc'
PLAN = json.loads((REPORT / 'plan.json').read_text())


def run(command, filename, *, cwd=ROOT, environment=None):
    start = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=environment, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    evidence = {'command': shlex.join(command), 'cwd': str(cwd), 'returncode': result.returncode,
                'seconds': round(time.monotonic() - start, 3), 'stdout': result.stdout}
    (REPORT / filename).write_text(json.dumps(evidence, indent=2) + '\n')
    return evidence


def clean(label, cwd=ROOT):
    checks = [run(['git', 'rev-parse', 'HEAD'], label + '-head.json', cwd=cwd),
              run(['git', 'diff', '--exit-code'], label + '-diff.json', cwd=cwd),
              run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], label + '-status.json', cwd=cwd)]
    assert checks[0]['returncode'] == 0 and checks[0]['stdout'].strip() == COMMIT, checks
    assert checks[1]['returncode'] == 0 and checks[2]['returncode'] == 0 and checks[2]['stdout'] == '', checks


def environment(name):
    result = os.environ.copy()
    result.update({'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT),
                   'AGENTSOCIETY_LLM_API_KEY': 'test-only', 'LITELLM_LOCAL_MODEL_COST_MAP': 'True',
                   'PYTHONPYCACHEPREFIX': str(REPORT / 'pycache' / name)})
    return result


def import_check(plan, label):
    code = ('import importlib; from pathlib import Path; '
            f'module=importlib.import_module({plan["module"]!r}); '
            'print(module.__file__); '
            f'assert Path(module.__file__).resolve().is_relative_to(Path({str(ROOT)!r}).resolve())')
    result = run([PYTHON, '-c', code], label + '-import.json', environment=environment(label))
    assert result['returncode'] == 0, result
    return result


def pytest(plan, label):
    command = [PYTHON, '-m', 'pytest', '-q', *plan['tests']]
    result = run(command, label + '-pytest.json', environment=environment(label))
    result['environment'] = {key: environment(label)[key] for key in (
        'PYTHONPATH', 'AGENTSOCIETY_LLM_API_KEY', 'LITELLM_LOCAL_MODEL_COST_MAP', 'PYTHONPYCACHEPREFIX')}
    (REPORT / (label + '-pytest.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'label': label, 'returncode': result['returncode'], 'seconds': result['seconds'],
                      'summary': result['stdout'].splitlines()[-1] if result['stdout'] else ''}), flush=True)
    return result


def baseline():
    clean('preflight-caller', CALLER)
    clean('preflight-detached')
    result = run(['git', 'worktree', 'list', '--porcelain'], 'registered-worktrees.json')
    assert result['returncode'] == 0
    for item in PLAN:
        target = ROOT / item['file']
        assert target.read_text().count(item['old']) == 1, item['name']
        import_check(item, 'baseline-' + item['name'])
        result = pytest(item, 'baseline-' + item['name'])
        if result['returncode'] != 0 or ' skipped' in result['stdout']:
            raise SystemExit('Blocked: baseline failed or skipped: ' + item['name'])
    clean('baseline-detached')
    (REPORT / 'baseline-complete.json').write_text(json.dumps({'commit': COMMIT, 'plans': len(PLAN)}))


def mutate(name):
    assert (REPORT / 'baseline-complete.json').exists()
    plan = next(item for item in PLAN if item['name'] == name)
    clean('before-' + name)
    target = ROOT / plan['file']
    original = target.read_bytes()
    text = original.decode()
    assert text.count(plan['old']) == 1
    changed = text.replace(plan['old'], plan['new'])
    ast.parse(changed, filename=str(target))
    try:
        target.write_text(changed)
        run(['git', 'diff', '--', plan['file']], 'mutant-' + name + '-patch.json')
        run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], 'mutant-' + name + '-status.json')
        import_check(plan, 'mutant-' + name)
        result = pytest(plan, 'mutant-' + name)
    finally:
        restored = run(['git', 'restore', '--source=' + COMMIT, '--', plan['file']], 'restore-' + name + '.json')
        assert restored['returncode'] == 0, restored
        assert target.read_bytes() == original
        clean('after-' + name)
    print(json.dumps({'name': name, 'restored': True, 'original_sha256': hashlib.sha256(original).hexdigest()}), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'baseline':
        baseline()
    elif sys.argv[1] == 'baseline_one':
        plan = next(item for item in PLAN if item['name'] == sys.argv[2])
        clean('before-baseline-' + plan['name'])
        import_check(plan, 'baseline-' + plan['name'])
        result = pytest(plan, 'baseline-' + plan['name'])
        assert result['returncode'] == 0 and ' skipped' not in result['stdout'], result
        clean('after-baseline-' + plan['name'])
    elif sys.argv[1] == 'mutate':
        mutate(sys.argv[2])
    else:
        raise SystemExit('Unknown review command')
