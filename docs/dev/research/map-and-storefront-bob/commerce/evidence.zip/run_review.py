import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/worldmock-map-bob-commerce')
PREFLIGHT = json.loads((ROOT / 'preflight.json').read_text())
TREE = Path(PREFLIGHT['worktree'])
PYTHON = str(Path(PREFLIGHT['caller']) / '.venv/bin/python')
PLAN = json.loads((ROOT / 'plan.json').read_text())
ENV = dict(os.environ, PYTHONPATH=f'{TREE}/src:{TREE}', PYTHONDONTWRITEBYTECODE='1',
           LITELLM_LOCAL_MODEL_COST_MAP='True', AGENTSOCIETY_LLM_API_KEY='test-only')
MODULES = ('worldmock.life.basket', 'worldmock.life.commerce', 'worldmock.life.opening_hours')


def git(*args):
    return subprocess.run(['git', '-C', str(TREE), *args], text=True, capture_output=True)


def clean():
    diff = git('diff', '--exit-code')
    status = git('status', '--porcelain=v1', '--untracked-files=all')
    head = git('rev-parse', 'HEAD').stdout.strip()
    evidence = {'diff_exit': diff.returncode, 'status': status.stdout, 'head': head}
    assert diff.returncode == 0 and status.returncode == 0 and not status.stdout, evidence
    assert head == PREFLIGHT['head'], evidence
    return evidence


def run(command, name):
    started = time.monotonic()
    with (ROOT / f'{name}.log').open('w') as stream:
        result = subprocess.run(command, cwd=TREE, env=ENV, stdout=stream,
                                stderr=subprocess.STDOUT, text=True, timeout=180)
    record = {'command': command, 'exit': result.returncode,
              'seconds': round(time.monotonic() - started, 3), 'log': str(ROOT / f'{name}.log')}
    return record


def imports(name):
    code = ('import importlib,json,pathlib; '
            f'root=pathlib.Path({str(TREE)!r}).resolve(); '
            f'mods=[importlib.import_module(name) for name in {MODULES!r}]; '
            'paths={mod.__name__:str(pathlib.Path(mod.__file__).resolve()) for mod in mods}; '
            'print(json.dumps(paths,indent=2)); '
            'assert all(root in pathlib.Path(path).parents for path in paths.values())')
    result = run([PYTHON, '-c', code], name)
    assert result['exit'] == 0, result
    return result


def test(node, name):
    return run([PYTHON, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', node], name)


def baseline():
    result = {'clean_before': clean(), 'imports': imports('baseline-imports'), 'tests': []}
    (ROOT / 'baseline.json').write_text(json.dumps(result, indent=2))
    seen = set()
    for mutant in PLAN:
        if mutant['node'] in seen:
            continue
        seen.add(mutant['node'])
        evidence = test(mutant['node'], f'baseline-{mutant["name"]}')
        result['tests'].append(evidence)
        (ROOT / 'baseline.json').write_text(json.dumps(result, indent=2))
        print(json.dumps({'baseline': mutant['name'], **evidence}), flush=True)
        assert evidence['exit'] == 0, evidence
        output = Path(evidence['log']).read_text()
        assert '1 passed' in output and 'skipped' not in output, output
    result['clean_after'] = clean()
    (ROOT / 'baseline.json').write_text(json.dumps(result, indent=2))
    print('BASELINE PASS; detached tree clean', flush=True)


def mutate(name):
    baseline_result = json.loads((ROOT / 'baseline.json').read_text())
    assert 'clean_after' in baseline_result
    mutant = next(row for row in PLAN if row['name'] == name)
    result = {'name': name, 'plan': mutant, 'clean_before': clean()}
    path = TREE / mutant['path']
    original = path.read_bytes()
    source = original.decode()
    assert source.count(mutant['old']) == 1, mutant
    changed = source.replace(mutant['old'], mutant['new'], 1)
    compile(changed, mutant['path'], 'exec')
    try:
        path.write_text(changed)
        (ROOT / f'{name}.diff').write_text(git('diff', '--', mutant['path']).stdout)
        result['imports'] = imports(f'{name}-imports')
        result['test'] = test(mutant['node'], f'mutant-{name}')
        result['provisional'] = 'survived' if result['test']['exit'] == 0 else 'failure_requires_causal_review'
    finally:
        path.write_bytes(original)
        result['restoration'] = clean()
        (ROOT / f'{name}.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({'name': name, 'test_exit': result['test']['exit'], 'import_exit': result['imports']['exit'], 'restoration': result['restoration']}, indent=2), flush=True)
    print(Path(result['test']['log']).read_text(), flush=True)


if sys.argv[1] == 'baseline':
    baseline()
else:
    mutate(sys.argv[1])
