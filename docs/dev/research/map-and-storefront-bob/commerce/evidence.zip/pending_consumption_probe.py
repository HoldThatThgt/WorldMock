import tempfile
from pathlib import Path
from tests.life.conftest import advance_next, stage_day_plan
from tests.life.test_commerce import _browse, _delivery_request, _observed_action, _stage_open
from tests.life.test_scheduling import _custom_engine
from worldmock.life.models import ConsumeItem, ConsumeRequest

def configure(document):
    document['messages'].append({'message_id': 'probe-mail', 'thread_id': 'probe-thread',
        'recipient_agent_id': 1, 'sent_at': '2026-01-05T10:00:02+08:00',
        'subject': 'Pending order decision opportunity', 'body': 'Test event before delivery',
        'related_task_id': None, 'attachment_sha256': None})

with tempfile.TemporaryDirectory(prefix='pending-consumption-', dir='/tmp/worldmock-map-bob-commerce') as folder:
    engine = _custom_engine('white-collar-12-weeks.json', configure, Path(folder),
                            run_id='read-only-pending-consumption')
    try:
        _stage_open(engine)
        stage_day_plan(engine)
        _browse(engine)
        product = engine.scenario.products[0]
        _, purchased = _observed_action(engine, 'probe-purchase', 'purchase',
                                       _delivery_request(engine, product.product_id))
        assert purchased.status == 'completed'
        order_id = purchased.data['orders'][0]['order_id']
        assert engine.state.deliveries[order_id].status == 'pending'
        assert engine.state.agents[1].inventory.get('home', {}).get(product.product_id, 0) == 0
        advance_next(engine)
        assert engine.state.current_time < engine.state.deliveries[order_id].expected_at
        _, consumed = _observed_action(engine, 'probe-consume-before-delivery', 'consume', ConsumeRequest(
            items=(ConsumeItem(product_id=product.product_id, quantity=1),),
            use_mode='eat', duration_seconds=product.use_duration_seconds))
        assert consumed.status == 'rejected' and consumed.error_code == 'PRODUCT_NOT_HELD'
        assert engine.state.deliveries[order_id].status == 'pending'
        assert engine.state.agents[1].inventory.get('home', {}).get(product.product_id, 0) == 0
        print('PASS: actual discover -> purchase pending -> next decision -> consume rejects PRODUCT_NOT_HELD; no inventory.')
    finally:
        engine.close()
