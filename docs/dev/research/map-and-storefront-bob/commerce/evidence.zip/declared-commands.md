# Predeclared mutation oracles

## selected_stock

SPEC lines 90. Deduct stock from the first frozen supply instead of the selected store.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_single_supply_changes_only_selected_shop_and_preserves_sources'
```

## selected_seller

SPEC lines 90. Credit the first frozen seller rather than the selected seller.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_single_supply_changes_only_selected_shop_and_preserves_sources'
```

## same_account_cross_location

SPEC lines 88. Remove the same-location requirement while retaining the seller check.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_whole_order_rejections_are_atomic[location-ORDER_LOCATION_MISMATCH]'
```

## duplicate_supply

SPEC lines 88-90. Accept duplicate supply identities in one order.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_whole_order_rejections_are_atomic[duplicate-ORDER_DUPLICATE_SUPPLY]'
```

## obsolete_quote

SPEC lines 56,90. Accept an obsolete quoted version using the current price.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_whole_order_rejections_are_atomic[price-PRICE_VERSION_MISMATCH]'
```

## closing_boundary

SPEC lines 52,54,56. Treat the exact closing minute as still open.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_purchase_uses_minute_boundary_and_world_opening_override'
```

## supply_qualification

SPEC lines 56. Ignore the selected supply membership requirement.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_purchase_requires_declared_supply_and_location_qualification[supply-SUPPLY_QUALIFICATION_REQUIRED]'
```

## maximum_preparation

SPEC lines 92. Start delivery at the fastest instead of the slowest item preparation time.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_whole_basket_uses_maximum_preparation_and_departure_traffic_once'
```

## departure_traffic

SPEC lines 92. Calculate traffic at order time rather than actual departure time.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_whole_basket_uses_maximum_preparation_and_departure_traffic_once'
```

## delivery_idempotence

SPEC lines 92,94. Allow an already delivered order to add inventory again on replay.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_storefront_commerce.py::test_delivery_is_due_atomic_and_idempotent_with_truthful_evidence'
```

## unheld_consumption

SPEC lines 25,92. Allow consumption to begin without locally held goods.

```sh
cd /tmp/worldmock-map-bob-commerce-tree.Cf8AeE
PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only PYTHONPATH=/tmp/worldmock-map-bob-commerce-tree.Cf8AeE/src:/tmp/worldmock-map-bob-commerce-tree.Cf8AeE /Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock/.venv/bin/python -m pytest -q -p no:cacheprovider 'tests/life/test_commerce.py::test_consume_rejects_inventory_held_at_another_location'
```

