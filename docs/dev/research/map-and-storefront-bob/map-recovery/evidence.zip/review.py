"""External isolated Bob runner; never edits tests or the caller checkout."""
from pathlib import Path
import json
import os
import shlex
import subprocess
import sys
import time

ROOT = Path('/tmp/worldmock-bob-map-recovery.UkJseg')
CALLER = Path('/Users/atishoo/.codex/worktrees/map-and-storefront/WorldMock')
LOG = Path('/tmp/worldmock-map-bob-map-recovery')
PYTHON = str(CALLER / '.venv/bin/python')
COMMIT = '2bce358a09046b84841bc5a2da68d82a66b79dbc'
ENV = dict(os.environ, PYTHONPATH=f'{ROOT}/src:{ROOT}', PYTHONDONTWRITEBYTECODE='1',
           LITELLM_LOCAL_MODEL_COST_MAP='True', AGENTSOCIETY_LLM_API_KEY='test-only')

PLANS = [
 dict(name='map_hash', clause='SPEC:33,48', module='worldmock.life.map_data',
      path='src/worldmock/life/map_data.py',
      old='if hashlib.sha256(content).hexdigest() != reference.sha256:',
      new='if False and hashlib.sha256(content).hexdigest() != reference.sha256:',
      tests=['tests/life/test_map_dataset.py::test_file_tampering_is_rejected_before_parsing'],
      behavior='Bypass frozen map file hash validation.'),
 dict(name='map_identity', clause='SPEC:37,48', module='worldmock.life.map_data',
      path='src/worldmock/life/map_data.py',
      old='if (declaration.dataset_id, declaration.version) != (reference.dataset_id, reference.version):',
      new='if False and (declaration.dataset_id, declaration.version) != (reference.dataset_id, reference.version):',
      tests=['tests/life/test_map_dataset.py::test_map_identity_pin_is_checked'],
      behavior='Accept a map whose declared version differs from its scenario pin.'),
 dict(name='actual_walking_mode', clause='SPEC:23,40,48', module='worldmock.life.map_data',
      path='src/worldmock/life/map_data.py', old='if modes != {expected}:', new='if False and modes != {expected}:',
      tests=['tests/life/test_map_dataset.py::test_reachable_routes_require_actual_geometry_mode_and_metrics'],
      behavior='Accept geometry whose actual step mode disagrees with the declared profile.'),
 dict(name='missing_location_environment', clause='SPEC:42', module='worldmock.life.map_models',
      path='src/worldmock/life/map_models.py', old='location_kinds: tuple[str, ...] = Field(min_length=1)',
      new='location_kinds: tuple[str, ...] = Field(default=("venue",), min_length=1)',
      tests=['tests/life/test_map_dataset.py::test_locations_reject_old_or_inferred_activity_environments'],
      behavior='Infer venue when a place omits the mandatory activity environment; retain nonempty validation.'),
 dict(name='review_fact_cutoff', clause='SPEC:52', module='worldmock.life.map_models',
      path='src/worldmock/life/map_models.py', old='if self.reviewed_on > self.source.fact_cutoff:',
      new='if False and self.reviewed_on > self.source.fact_cutoff:',
      tests=['tests/life/test_map_dataset.py::test_review_cannot_claim_facts_after_the_source_cutoff'],
      behavior='Permit a declaration reviewed after its source fact cutoff.'),
 dict(name='complete_route_matrix', clause='SPEC:48,72', module='worldmock.life.map_data',
      path='src/worldmock/life/map_data.py', old='if expected != actual:', new='if False and expected != actual:',
      tests=['tests/life/test_map_dataset.py::test_missing_route_record_cannot_mean_unreachable'],
      behavior='Accept a selected directed location/mode pair that has no explicit route status record.'),
 dict(name='unknown_route_travel', clause='SPEC:72', module='worldmock.life.travel',
      path='src/worldmock/life/travel.py', old='if matches[0].status != "reachable":',
      new='if matches[0].status == "unreachable":',
      tests=['tests/life/test_storefront_state_validation.py::test_route_selection_rejects_explicit_non_reachable_status'],
      behavior='Allow an explicitly unknown route to pass travel route selection.'),
 dict(name='arrival_access', clause='SPEC:56', module='worldmock.life.storefront_runtime',
      path='src/worldmock/life/storefront_runtime.py',
      old='missing = sorted(set(location.required_qualifications) - set(agent.qualifications))',
      new='missing = []',
      tests=['tests/life/test_storefront_arrival.py::test_arrival_rechecks_access_and_records_denial_without_undoing_real_travel'],
      behavior='Ignore missing access qualifications at actual arrival while leaving completed trip processing intact.'),
 dict(name='lifestyle_resume_environment', clause='SPEC:82,84', module='worldmock.life.engine',
      path='src/worldmock/life/engine.py',
      old='if request.operation == ActivityChange.RESUME:\n            self.rules.validate_activity_location(agent, current.kind, current.target_id)',
      new='if request.operation == ActivityChange.RESUME:\n            pass',
      tests=['tests/life/test_storefront_arrival.py::test_paused_lifestyle_cannot_resume_after_real_travel_to_incompatible_environment'],
      behavior='Skip the activity environment recheck on resume after an actual pause and trip.'),
 dict(name='restored_quote_timeline', clause='SPEC:58,102', module='worldmock.life.storefront_state',
      path='src/worldmock/life/storefront_state.py',
      old='if state.supply_quotes != expected_supply_quotes(scenario, state.current_time):',
      new='if False and state.supply_quotes != expected_supply_quotes(scenario, state.current_time):',
      tests=['tests/life/test_storefront_recovery.py::test_reopening_rejects_corrupted_storefront_facts'],
      behavior='Accept persisted quote price/version/source/validity facts that disagree with the declared event timeline.'),
 dict(name='branch_parent_directory', clause='SPEC:102', module='worldmock.footprints.checkpoint',
      path='src/worldmock/footprints/checkpoint.py',
      old='atomic_write(stage / "restored-checkpoint.json", canonical_json(checkpoint.model_dump()))',
      new='atomic_write(stage / "restored-checkpoint.json", canonical_json(checkpoint.model_dump()))\n        atomic_write(store.run_dir / "restored-checkpoint.json", canonical_json(checkpoint.model_dump()))',
      tests=['tests/life/test_storefront_recovery.py::test_discovery_purchase_consumption_and_recovery_preserve_storefront_evidence',
             'tests/footprints/test_branch_coverage.py::test_restore_branch_carries_event_artifacts_into_child_run'],
      behavior='Also write restoration metadata into the parent run directory when creating a branch.'),
]

PLANS.append(dict(name='closing_boundary', clause='SPEC:52,54,56', module='worldmock.life.opening_hours',
    path='src/worldmock/life/opening_hours.py',
    old='< (midnight + timedelta(minutes=item.closes)).timestamp() for item in intervals)',
    new='<= (midnight + timedelta(minutes=item.closes)).timestamp() for item in intervals)',
    tests=['tests/life/test_storefront_commerce.py::test_purchase_uses_minute_boundary_and_world_opening_override'],
    behavior='Treat the exact closing minute as still open during actual purchase settlement.'))


def command(plan):
    return [PYTHON, '-m', 'pytest', '-q', *plan['tests'], '--tb=short',
            f'--basetemp={LOG}/pytest-{plan["name"]}']


def command_text(plan):
    return 'PYTHONPATH=' + shlex.quote(ENV['PYTHONPATH']) + ' PYTHONDONTWRITEBYTECODE=1 LITELLM_LOCAL_MODEL_COST_MAP=True AGENTSOCIETY_LLM_API_KEY=test-only ' + shlex.join(command(plan))


def run(arguments, log_path):
    start = time.time()
    result = subprocess.run(arguments, cwd=ROOT, env=ENV, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    log_path.write_text(result.stdout)
    return dict(returncode=result.returncode, elapsed_seconds=round(time.time() - start, 3),
                log=str(log_path), tail=result.stdout[-2400:])


def clean(label):
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    diff = subprocess.run(['git', 'diff', '--exit-code'], cwd=ROOT, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=ROOT, text=True)
    proof = dict(head=head, diff_returncode=diff.returncode, diff=diff.stdout, status=status)
    (LOG / f'{label}.clean.json').write_text(json.dumps(proof, indent=2))
    if head != COMMIT or diff.returncode or status:
        raise RuntimeError(f'Isolation is not clean: {proof}')
    return proof


def import_check(plan, label):
    code = (f'from pathlib import Path; import importlib; '
            f'm=importlib.import_module({plan["module"]!r}); p=Path(m.__file__).resolve(); '
            f'print(p); assert p.is_relative_to(Path({str(ROOT)!r}).resolve()); '
            f'compile(p.read_text(), str(p), "exec")')
    return run([PYTHON, '-c', code], LOG / f'{label}.import.log')


def baseline_all():
    clean('baseline-start')
    results = []
    for plan in PLANS:
        label = 'baseline-' + plan['name']
        checked = import_check(plan, label)
        if checked['returncode']:
            raise RuntimeError(f'Baseline import failed: {checked}')
        tested = run(command(plan), LOG / f'{label}.pytest.log')
        row = dict(name=plan['name'], command=command_text(plan), import_check=checked, test=tested)
        results.append(row)
        (LOG / 'baseline-results.json').write_text(json.dumps(results, indent=2))
        print(json.dumps(row), flush=True)
        if tested['returncode'] or ' skipped' in tested['tail']:
            raise RuntimeError(f'Baseline did not pass without skips: {tested}')
    clean('baseline-complete')


def mutate(name):
    plan = next(row for row in PLANS if row['name'] == name)
    baseline = json.loads((LOG / 'baseline-results.json').read_text())
    assert len(baseline) == len(PLANS) and all(row['test']['returncode'] == 0 for row in baseline)
    clean('before-' + name)
    path = ROOT / plan['path']
    original = path.read_text()
    assert original.count(plan['old']) == 1, 'Mutation anchor is not unique'
    result = dict(name=name, started_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  clause=plan['clause'], command=command_text(plan), behavior=plan['behavior'])
    try:
        path.write_text(original.replace(plan['old'], plan['new']))
        result['diff'] = subprocess.check_output(['git', 'diff', '--', plan['path']], cwd=ROOT, text=True)
        (LOG / f'{name}.diff').write_text(result['diff'])
        result['import_check'] = import_check(plan, name)
        if result['import_check']['returncode']:
            result['provisional_outcome'] = 'invalid'
        else:
            result['test'] = run(command(plan), LOG / f'{name}.pytest.log')
            result['provisional_outcome'] = 'needs-causal-review' if result['test']['returncode'] else 'needs-reachability-review'
            if name == 'missing_location_environment':
                code = ('from tests.life.test_opening_hours import location; '
                        'from worldmock.life.map_models import LocationConfig; '
                        'payload=location().model_dump(); payload.pop("location_kinds"); '
                        'actual=LocationConfig.model_validate(payload); '
                        'print("omitted input location_kinds accepted as", actual.location_kinds)')
                result['diagnostic'] = run([PYTHON, '-c', code], LOG / f'{name}.diagnostic.log')
            if name == 'branch_parent_directory':
                files = []
                for metadata in sorted((LOG / f'pytest-{name}').rglob('restored-checkpoint.json')):
                    manifest_path = metadata.parent / 'manifest.json'
                    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
                    files.append(dict(path=str(metadata), run_id=manifest.get('run_id'),
                                      parent_run_id=manifest.get('parent_run_id')))
                result['diagnostic'] = files
                (LOG / f'{name}.diagnostic.json').write_text(json.dumps(files, indent=2))
    finally:
        subprocess.run(['git', 'restore', '--source', COMMIT, '--', plan['path']], cwd=ROOT, check=True)
        result['restoration'] = clean('after-' + name)
        (LOG / f'{name}.result.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'plan':
        plans = [{**plan, 'command': command_text(plan)} for plan in PLANS]
        (LOG / 'plan.json').write_text(json.dumps(plans, indent=2))
        print(json.dumps(plans, indent=2))
    elif sys.argv[1] == 'baseline':
        baseline_all()
    elif sys.argv[1] == 'mutate':
        mutate(sys.argv[2])
