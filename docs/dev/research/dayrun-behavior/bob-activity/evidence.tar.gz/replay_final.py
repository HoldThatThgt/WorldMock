from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

TREE = Path('/tmp/worldmock-bob-activity-final.Kfo5ZH')
EVIDENCE = Path('/tmp/worldmock-bob-activity-evidence')
RESULTS = EVIDENCE / 'final'
RESULTS.mkdir(exist_ok=True)
PYTHON = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
TESTS = [
    'tests/life/test_parallel_activities.py',
    'tests/life/test_parallel_acceptance.py',
    'tests/life/test_shared_body.py',
    'tests/life/test_wake_reasons.py',
    'tests/life/test_day_plan.py',
    'tests/life/test_energy_feasibility.py',
]
SOURCES = {
    'second_goal_ignored': 'src/worldmock/life/rhythm.py',
    'task_deadline_identity': 'src/worldmock/life/rhythm.py',
    'closing_boundary_identity': 'src/worldmock/life/rhythm.py',
    'closing_commitment_identity': 'src/worldmock/life/rhythm.py',
    'threat_clear_on_disappear': 'src/worldmock/life/rhythm.py',
}

def git(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(['git', *args], cwd=TREE, text=True, capture_output=True, check=check)


def main(name: str) -> None:
    source = SOURCES[name]
    patch = EVIDENCE / f'{name}.patch'
    patch_bytes = patch.read_bytes()
    assert not git('status', '--porcelain=v1', '--untracked-files=all').stdout
    git('apply', '--check', str(patch))
    git('apply', str(patch))
    actual = git('diff', '--', source).stdout.encode()
    assert actual == patch_bytes, f'{name}: applied diff differs from original patch'
    started = time.monotonic()
    run = None
    try:
        env = os.environ.copy()
        env.update(MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
                   LITELLM_LOCAL_MODEL_COST_MAP='True',
                   PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2')
        command = [PYTHON, '-m', 'pytest', '-q', *TESTS]
        run = subprocess.run(command, cwd=TREE, env=env, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (RESULTS / f'{name}.log').write_text(run.stdout)
        (RESULTS / f'{name}.json').write_text(json.dumps({
            'commit': '9a62963841694cb668cc49a039c59f39caa757a6',
            'name': name, 'patch_sha256': hashlib.sha256(patch_bytes).hexdigest(),
            'patch_exact': True, 'command': ' '.join(command),
            'exit_code': run.returncode, 'seconds': round(time.monotonic() - started, 2),
        }, indent=2) + '\n')
    finally:
        git('restore', '--source=HEAD', '--', source)
        diff = git('diff', '--exit-code')
        status = git('status', '--porcelain=v1', '--untracked-files=all').stdout
        assert diff.returncode == 0 and not status, f'restoration failed: {diff.stdout} {status}'
    assert run is not None
    print(f'{name}: exit={run.returncode} seconds={time.monotonic() - started:.2f} restoration=clean')
    print('\n'.join(run.stdout.splitlines()[-14:]))

if __name__ == '__main__':
    main(sys.argv[1])
