from __future__ import annotations

import json
import sys
from pathlib import Path

from tests.life.conftest import advance_next
from tests.life.test_day_plan import goal
from tests.life.test_parallel_acceptance import _engine, _parallel, _watch
from tests.life.test_revision_contract import _commit_staged
from worldmock.life.models import StartBasicActivityRequest
from worldmock.life.schedule import DayPlan, day_end_seconds

run_root = Path('/tmp/worldmock-bob-activity-evidence/probe-runs') / sys.argv[1]
run_root.mkdir(parents=True, exist_ok=True)
engine = _engine(run_root)
try:
    now = engine.state.current_time
    staged = engine.state.model_copy(deep=True)
    staged.agents[1] = staged.agents[1].model_copy(update={'day_plan': DayPlan(
        day_end=day_end_seconds(now, engine.scenario.timezone), goals=(
            goal('休息', '真实等待', registered=now - 1),
            goal('娱乐', '真实播放', registered=now - 1),
        ))}, deep=True)
    _commit_staged(engine, staged)
    result, identities = _parallel(
        engine, 'two-goal-probe', _watch(120),
        StartBasicActivityRequest(activity_type='wait', planned_duration_seconds=120))
    assert result.status == 'in_progress' and len(identities) == 2
    advance_next(engine)
    output = {
        'time_advanced': engine.state.current_time - now,
        'activities': {item.kind.value: item.status.value for item in engine.state.activities.values()
                       if item.activity_id in identities},
        'goals': {item.intent_kind: {'progressed_at': item.progressed_at,
                                    'activity_id': item.progress_activity_id}
                  for item in engine.state.agents[1].day_plan.goals},
    }
    print(json.dumps(output, ensure_ascii=False, sort_keys=True))
finally:
    engine.close()
