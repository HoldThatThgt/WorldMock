from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

TREE = Path('/tmp/worldmock-bob-activity-recheck.7cYzyF')
EVIDENCE = Path('/tmp/worldmock-bob-activity-evidence')
PYTHON = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
TESTS = [
    'tests/life/test_parallel_activities.py',
    'tests/life/test_parallel_acceptance.py',
    'tests/life/test_shared_body.py',
    'tests/life/test_wake_reasons.py',
    'tests/life/test_day_plan.py',
    'tests/life/test_energy_feasibility.py',
]
MUTANTS = {
    'watch_controls_position': ('src/worldmock/catalog/affordances.py',
        'claims = set(spec.resource_claims)',
        'claims = set(spec.resource_claims) | ({"position"} if kind_value == "watch" else set())'),
    'task_deadline_identity': ('src/worldmock/life/rhythm.py',
        'return json.dumps(["task", task_id, due_at], ensure_ascii=False, separators=(",", ":"))',
        'return json.dumps(["task", task_id], ensure_ascii=False, separators=(",", ":"))'),
    'closing_boundary_identity': ('src/worldmock/life/rhythm.py',
        '["closing", agent.location_id, close_at, commitment]',
        '["closing", agent.location_id, commitment]'),
    'closing_commitment_identity': ('src/worldmock/life/rhythm.py',
        '["closing", agent.location_id, close_at, commitment]',
        '["closing", agent.location_id, close_at]'),
    'threat_clear_on_disappear': ('src/worldmock/life/rhythm.py',
        'delivered = set(agent.delivered_warning_signatures) & current',
        'delivered = set(agent.delivered_warning_signatures)'),
    'inventory_validation': ('src/worldmock/life/engine.py',
        'if recipe is None:\n            validate_meal_inventory(agent, request)',
        'if recipe is None and False:\n            validate_meal_inventory(agent, request)'),
    'mixed_energy': ('src/worldmock/life/engine.py',
        'self._require_energy_plan(staged, staged.agents[pending.agent_id])',
        'pass  # Bob mutation: skip combined energy admission'),
    'early_aggregate': ('src/worldmock/life/action_evidence.py',
        'if any(activity.status not in terminal for activity in activities):',
        'if False:'),
    'pause_transition': ('src/worldmock/life/activities.py',
        'activity.model_copy(update={"status": ActivityStatus.PAUSED,',
        'activity.model_copy(update={"status": ActivityStatus.ACTIVE,'),
    'basal_once': ('src/worldmock/life/body.py',
        'met = max((factors.met for _, factors in activities), default=1.0)\n    basal = config.basal_kcal_per_hour * hours',
        'met = max((factors.met for _, factors in activities), default=1.0)\n    basal = config.basal_kcal_per_hour * hours * max(1, len(activities))'),
    'max_met': ('src/worldmock/life/body.py',
        'met = max((factors.met for _, factors in activities), default=1.0)',
        'met = sum((factors.met for _, factors in activities), start=0.0) or 1.0'),
    'prediction_endpoint': ('src/worldmock/life/body.py',
        'met = max((value for seconds, value in activities if seconds > previous), default=1.0)',
        'met = max((value for seconds, value in activities if seconds >= previous), default=1.0)'),
    'sleep_consumes_warning': ('src/worldmock/life/rhythm.py',
        'if offered:\n            delivered.update(_delivered_warning_signatures(warning_facts, verdict))',
        'if offered or warning_facts["task"]:\n            delivered.update(warning_facts["task"])'),
    'second_task_suppressed': ('src/worldmock/life/rhythm.py',
        'and due - rhythm_schedule.TASK_DUE_SOON_SECONDS <= now < due}\n    closing: set[str] = set()',
        'and due - rhythm_schedule.TASK_DUE_SOON_SECONDS <= now < due}\n    task = {min(task)} if task else set()\n    closing: set[str] = set()'),
    'repeated_warning': ('src/worldmock/life/rhythm.py',
        'delivered = set(agent.delivered_warning_signatures) & current',
        'delivered = set()'),
    'second_goal_ignored': ('src/worldmock/life/rhythm.py',
        'for data in inputs.progress_data.get(agent.agent_id, []):',
        'for data in inputs.progress_data.get(agent.agent_id, [])[:2]:'),
}

def git(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(['git', *args], cwd=TREE, text=True, capture_output=True, check=check)


def main(name: str) -> None:
    path, old, new = MUTANTS[name]
    source = TREE / path
    assert not git('status', '--porcelain=v1', '--untracked-files=all').stdout
    data = source.read_text()
    assert data.count(old) == 1, f'{name}: old text not unique'
    assert old != new
    source.write_text(data.replace(old, new, 1))
    started = time.monotonic()
    result = None
    try:
        patch = git('diff', '--', path).stdout
        assert patch.strip(), 'empty patch'
        (EVIDENCE / f'{name}.patch').write_text(patch)
        env = os.environ.copy()
        env.update(MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
                   LITELLM_LOCAL_MODEL_COST_MAP='True',
                   PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2')
        command = [PYTHON, '-m', 'pytest', '-q', *TESTS]
        result = subprocess.run(command, cwd=TREE, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (EVIDENCE / f'{name}.log').write_text(result.stdout)
        metadata = dict(name=name, source=path, command=' '.join(command),
                        exit_code=result.returncode, seconds=round(time.monotonic() - started, 2),
                        patch_sha256=hashlib.sha256(patch.encode()).hexdigest())
        (EVIDENCE / f'{name}.json').write_text(json.dumps(metadata, indent=2) + '\n')
    finally:
        git('restore', '--source=HEAD', '--', path)
        diff = git('diff', '--exit-code')
        status = git('status', '--porcelain=v1', '--untracked-files=all').stdout
        assert diff.returncode == 0 and not status, f'restoration failed: {diff.stdout} {status}'
    assert result is not None
    print(f'{name}: exit={result.returncode} seconds={time.monotonic() - started:.2f} restoration=clean')
    print('\n'.join(result.stdout.splitlines()[-12:]))

if __name__ == '__main__':
    main(sys.argv[1])
