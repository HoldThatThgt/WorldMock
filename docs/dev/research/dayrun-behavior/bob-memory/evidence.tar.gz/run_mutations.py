from __future__ import annotations

import difflib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/tmp/worldmock-bob-memory-tree.Q3KgLw')
OUT = Path('/tmp/worldmock-bob-memory-evidence')
PYTHON = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
TESTS = [
    'tests/integration/test_verified_memory.py',
    'tests/integration/test_dayrun_parallel_agent.py',
    'tests/integration/test_parallel_rejection_contract.py',
    'tests/integration/test_activity_schema.py',
    'tests/integration/test_life_agent_protocol.py',
    'tests/life/test_memory_evidence.py',
    'vendor/agentsociety2/packages/agentsociety2/tests/test_memory_restore.py',
]
COMMAND = [PYTHON, '-m', 'pytest', '-q', *TESTS]
ENV = dict(os.environ)
ENV.update(
    PYTHONPATH=':'.join((str(ROOT / 'vendor/agentsociety2/packages/agentsociety2'),
                         str(ROOT / 'src'), str(ROOT))),
    AGENTSOCIETY_LLM_API_KEY='test-only',
    AGENTSOCIETY_LLM_API_BASE='https://example.invalid',
    MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
    LITELLM_LOCAL_MODEL_COST_MAP='True',
)
MUTATIONS = [
    ('menu_child', 'custom/agents/life_menu.py',
     'for item in request.activities:\n            error = menu_action_error',
     'for item in request.activities[:0]:\n            error = menu_action_error'),
    ('group_resources', 'custom/agents/life_activity_controls.py',
     '            occupied = occupied | claims\n',
     '            occupied = occupied\n'),
    ('child_target', 'custom/agents/life_agent.py',
     'for item in request.activities:\n            error = _validate_prepared_action',
     'for item in request.activities[:0]:\n            error = _validate_prepared_action'),
    ('control_identity', 'custom/agents/life_activity_controls.py',
     '"watch_ids": tuple(identity for identity, row in active.items() if row["kind"] == "watch")',
     '"watch_ids": tuple(active)'),
    ('old_fact_prompt', 'custom/agents/life_memory.py',
     '"memory_md": _prompt_memory(self._owner._persona_card_text(), summary),',
     '"memory_md": store.read_memory_md(),'),
    ('identity_pollution', 'custom/agents/life_memory.py',
     'header = ("# Memory\\n\\n## 身份\\n" + _quote(identity) +',
     'header = ("# Memory\\n\\n## 身份\\n" + _quote(summary) +'),
    ('drop_current_fact', 'custom/agents/life_memory.py',
     '        return facts, observation_id\n',
     '        return facts[:-1], observation_id\n'),
    ('reflection_identity', 'custom/agents/life_memory.py',
     'written.extend(await self._run_reflection(tick=tick, t=t, step_count=step_count))',
     'await self._run_reflection(tick=tick, t=t, step_count=step_count)'),
    ('silent_memory_write', 'custom/agents/life_memory.py',
     '        if not written:\n            logging.error("Memory store did not persist finish memories")',
     '        if written is None:\n            logging.error("Memory store did not persist finish memories")'),
    ('empty_memory_rejected', 'custom/agents/life_memory.py',
     '        if not memories:\n            return []\n',
     '        if not memories:\n            raise RuntimeError("Empty memory update rejected")\n'),
    ('retrieval_status', 'vendor/agentsociety2/packages/agentsociety2/agentsociety2/agent/memory_runtime.py',
     'data = {"epistemic_status": "subjective", "episodes": store.recent(limit=int(args.get("limit") or 8))}',
     'data = {"epistemic_status": "objective", "episodes": store.recent(limit=int(args.get("limit") or 8))}'),
    ('view_resets_counter', 'vendor/agentsociety2/packages/agentsociety2/agentsociety2/agent/memory.py',
     '        self.memory_md_path.write_text(normalized, encoding="utf-8")\n        return True\n',
     '        self.memory_md_path.write_text(normalized, encoding="utf-8")\n'
     '        state = self.read_state()\n'
     '        state["pending_episode_count"] = 0\n'
     '        self.write_state(state)\n'
     '        return True\n'),
    ('restore_objective', 'vendor/agentsociety2/packages/agentsociety2/agentsociety2/agent/memory.py',
     '        if item["epistemic_status"] != "subjective":\n',
     '        if item["epistemic_status"] not in {"subjective", "objective"}:\n'),
    ('source_window_evidence', 'src/worldmock/life/engine.py',
     '            if set(evidence.verified_event_ids) != visible_ids:\n',
     '            if False:\n'),
    ('forged_visible_ref', 'custom/agents/life_agent.py',
     '    return {observation_id, *result_ids, *(item["source_event_id"] for item in data["verified_experiences"])}',
     '    return {observation_id, "decision:action:0001", *result_ids, '
     '*(item["source_event_id"] for item in data["verified_experiences"])}'),
    ('identity_reversed', 'custom/agents/life_memory.py',
     'header = ("# Memory\\n\\n## 身份\\n" + _quote(identity) +',
     'header = ("# Memory\\n\\n## 身份\\n" + _quote(identity[::-1]) +'),
    ('summary_as_fact', 'custom/agents/life_agent.py',
     'parts.append("主观归纳：\\n" + summary.strip())',
     'parts.append("已核验经历：\\n" + summary.strip())'),
    ('merged_identity_omitted', 'custom/agents/life_memory.py',
     '    merged = tuple(item for identity, item in by_id.items() if identity in known)',
     '    merged = ()'),
    ('quality_merge_duplicate', 'src/worldmock/footprints/quality.py',
     '    duplicates = sorted(set(created) & state["known"][event.agent_id])',
     '    duplicates = sorted(set(created + merged) & state["known"][event.agent_id])'),
]


def clean() -> tuple[bool, str]:
    commands = [
        (ROOT, ['git', 'diff', '--exit-code']),
        (ROOT, ['git', 'status', '--porcelain=v1', '--untracked-files=all']),
        (ROOT / 'vendor/agentsociety2', ['git', 'diff', '--exit-code']),
        (ROOT / 'vendor/agentsociety2', ['git', 'status', '--porcelain=v1', '--untracked-files=all']),
    ]
    output = []
    valid = True
    for directory, command in commands:
        result = subprocess.run(command, cwd=directory, capture_output=True, text=True)
        output.append(f'{directory}: {command}: exit={result.returncode}: {result.stdout}{result.stderr}')
        valid &= result.returncode == 0 and not result.stdout and not result.stderr
    return valid, '\n'.join(output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    results = []
    for name, relative, old, new in MUTATIONS:
        valid, detail = clean()
        if not valid:
            raise RuntimeError(f'pre-mutation tree is dirty before {name}: {detail}')
        path = ROOT / relative
        original = path.read_text()
        if original.count(old) != 1:
            raise RuntimeError(f'{name}: expected exactly one source match, found {original.count(old)}')
        modified = original.replace(old, new, 1)
        patch = ''.join(difflib.unified_diff(
            original.splitlines(keepends=True), modified.splitlines(keepends=True),
            fromfile=f'a/{relative}', tofile=f'b/{relative}'))
        (OUT / f'{name}.patch').write_text(patch)
        try:
            path.write_text(modified)
            result = subprocess.run(COMMAND, cwd=ROOT, env=ENV, capture_output=True, text=True)
            output = result.stdout + result.stderr
            (OUT / f'{name}.test.log').write_text(output)
            results.append({'name': name, 'file': relative, 'exit': result.returncode,
                            'tail': '\n'.join(output.splitlines()[-12:])})
            print(json.dumps(results[-1], ensure_ascii=False), flush=True)
        finally:
            path.write_text(original)
            valid, detail = clean()
            (OUT / f'{name}.restore.log').write_text(detail)
            if not valid:
                raise RuntimeError(f'{name}: restoration failed: {detail}')
    (OUT / 'mutation_results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
