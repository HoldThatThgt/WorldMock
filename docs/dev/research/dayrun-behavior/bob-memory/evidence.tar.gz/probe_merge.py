from __future__ import annotations

import subprocess

import run_mutations as review

CODE = r'''
import asyncio
import json
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from agentsociety2.agent.memory_runtime import MemoryRuntimeConfig
from custom.agents.life_memory import WorldMockMemoryRuntime

async def no_call(**_):
    raise RuntimeError('unexpected model call')

async def main():
    with tempfile.TemporaryDirectory(prefix='merge-probe-', dir='/tmp/worldmock-bob-memory-evidence') as scratch:
        owner = SimpleNamespace(
            id=1, name='Person', _model_name='fixture', _dispatch_memory_llm=no_call,
            get_profile=lambda: {'name': 'Person'}, _logger=SimpleNamespace(warning=lambda *a: None),
            trace_span=None, _persona_card_text=lambda: 'Frozen Person',
            _life_verified_experiences=[], _life_observation_event_id='observation-1')
        runtime = WorldMockMemoryRuntime(owner, MemoryRuntimeConfig())
        runtime.ensure_store(Path(scratch))
        memory = {'type': 'goal', 'importance': 0.1, 'text': '我希望明天再散步',
                  'source': 'decision_observation', 'refs': ['observation-1'],
                  'epistemic_status': 'subjective'}
        first = await runtime.after_step(tick=60, t=datetime(2026, 9, 21, tzinfo=timezone.utc),
                                         step_count=1, finish_memories=[memory])
        second = await runtime.after_step(tick=60, t=datetime(2026, 9, 21, 1, tzinfo=timezone.utc),
                                          step_count=2, finish_memories=[memory])
        record = runtime.store.iter_episodes()[0]
        print(json.dumps({'first_created': [item['id'] for item in first.created_episodes],
                          'second_created': [item['id'] for item in second.created_episodes],
                          'second_merged': [item['id'] for item in second.merged_episodes],
                          'stored_merge_count': record['merge_count']}, ensure_ascii=False))

asyncio.run(main())
'''

name, relative, old, new = next(item for item in review.MUTATIONS if item[0] == 'merged_identity_omitted')
path = review.ROOT / relative
original = path.read_text()
if original.count(old) != 1:
    raise RuntimeError('source mismatch')

for label, content in (('baseline', original), ('mutated', original.replace(old, new, 1))):
    valid, detail = review.clean()
    if not valid:
        raise RuntimeError(detail)
    try:
        path.write_text(content)
        result = subprocess.run([review.PYTHON, '-c', CODE], cwd=review.ROOT,
                                env=review.ENV, capture_output=True, text=True)
        (review.OUT / f'merged_identity_omitted.{label}.probe.log').write_text(
            f'exit={result.returncode}\n{result.stdout}{result.stderr}')
        print(label, result.returncode, result.stdout.strip())
        if result.returncode:
            raise RuntimeError(result.stderr)
    finally:
        path.write_text(original)
        valid, detail = review.clean()
        if not valid:
            raise RuntimeError(f'{label}: restoration failed: {detail}')
