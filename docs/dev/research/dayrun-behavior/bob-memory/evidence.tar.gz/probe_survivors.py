from __future__ import annotations

import subprocess
from pathlib import Path

import run_mutations as review

PROBES = {
    'identity_reversed': (
        'from custom.agents.life_memory import render_memory_view; '
        'view = render_memory_view("Alice", [], "我想吃饭"); '
        'print(view.split("## 身份\\n", 1)[1].split("\\n\\n", 1)[0])'
    ),
    'summary_as_fact': (
        'from custom.agents.life_agent import LifeAgent; '
        'agent = LifeAgent(); agent._enable_memory = True; '
        'agent._life_visible_refs = set(); '
        'agent._build_memory_context = lambda: '
        '{"subjective_summary": "我已经吃完饭", "recent_episodes": []}; '
        'print(agent._memory_prompt_section())'
    ),
}

for name, relative, old, new in review.MUTATIONS:
    if name not in PROBES:
        continue
    valid, detail = review.clean()
    if not valid:
        raise RuntimeError(detail)
    path = review.ROOT / relative
    original = path.read_text()
    if original.count(old) != 1:
        raise RuntimeError(f'{name}: source mismatch')
    try:
        path.write_text(original.replace(old, new, 1))
        result = subprocess.run(
            [review.PYTHON, '-c', PROBES[name]], cwd=review.ROOT,
            env=review.ENV, capture_output=True, text=True)
        (review.OUT / f'{name}.probe.log').write_text(
            f'exit={result.returncode}\n{result.stdout}{result.stderr}')
        print(name, result.returncode, result.stdout.strip())
        if result.returncode:
            raise RuntimeError(result.stderr)
    finally:
        path.write_text(original)
        valid, detail = review.clean()
        if not valid:
            raise RuntimeError(f'{name}: restoration failed: {detail}')
