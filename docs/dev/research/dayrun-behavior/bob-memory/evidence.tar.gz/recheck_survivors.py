from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/tmp/worldmock-bob-memory-recheck.EALBJF')
OUT = Path('/tmp/worldmock-bob-memory-evidence')
PYTHON = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
TESTS = [
    'tests/integration/test_verified_memory.py',
    'tests/integration/test_dayrun_parallel_agent.py',
    'tests/integration/test_parallel_rejection_contract.py',
    'tests/integration/test_activity_schema.py',
    'tests/integration/test_life_agent_protocol.py',
    'tests/life/test_memory_evidence.py',
    'vendor/agentsociety2/packages/agentsociety2/tests/test_memory_restore.py',
]
COMMAND = [PYTHON, '-m', 'pytest', '-q', *TESTS]
ENV = dict(os.environ)
ENV.update(
    PYTHONPATH=':'.join((str(ROOT / 'vendor/agentsociety2/packages/agentsociety2'),
                         str(ROOT / 'src'), str(ROOT))),
    AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='https://example.invalid',
    MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False', LITELLM_LOCAL_MODEL_COST_MAP='True',
)
NAMES = ('identity_reversed', 'summary_as_fact', 'merged_identity_omitted')


def clean() -> tuple[bool, str]:
    commands = (
        (ROOT, ('git', 'diff', '--exit-code')),
        (ROOT, ('git', 'status', '--porcelain=v1', '--untracked-files=all')),
        (ROOT / 'vendor/agentsociety2', ('git', 'diff', '--exit-code')),
        (ROOT / 'vendor/agentsociety2', ('git', 'status', '--porcelain=v1', '--untracked-files=all')),
    )
    details = []
    good = True
    for directory, command in commands:
        run = subprocess.run(command, cwd=directory, capture_output=True, text=True)
        details.append(f'{directory}: {command}: exit={run.returncode}; {run.stdout}{run.stderr}')
        good &= run.returncode == 0 and not run.stdout and not run.stderr
    return good, '\n'.join(details)


results = []
for name in NAMES:
    good, detail = clean()
    if not good:
        raise RuntimeError(f'pre-patch tree dirty: {name}: {detail}')
    patch = OUT / f'{name}.patch'
    check = subprocess.run(('git', 'apply', '--check', str(patch)), cwd=ROOT,
                           capture_output=True, text=True)
    if check.returncode:
        raise RuntimeError(f'{name}: saved patch no longer applies: {check.stderr}')
    apply = subprocess.run(('git', 'apply', str(patch)), cwd=ROOT,
                           capture_output=True, text=True)
    if apply.returncode:
        raise RuntimeError(f'{name}: apply failed: {apply.stderr}')
    try:
        result = subprocess.run(COMMAND, cwd=ROOT, env=ENV, capture_output=True, text=True)
        output = result.stdout + result.stderr
        (OUT / f'recheck_{name}.test.log').write_text(output)
        row = {'name': name, 'exit': result.returncode,
               'tail': '\n'.join(output.splitlines()[-12:])}
        results.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
    finally:
        reverse = subprocess.run(('git', 'apply', '--reverse', str(patch)), cwd=ROOT,
                                 capture_output=True, text=True)
        if reverse.returncode:
            raise RuntimeError(f'{name}: patch reversal failed: {reverse.stderr}')
        good, detail = clean()
        (OUT / f'recheck_{name}.restore.log').write_text(detail)
        if not good:
            raise RuntimeError(f'{name}: restoration failed: {detail}')
(OUT / 'recheck_results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False))
