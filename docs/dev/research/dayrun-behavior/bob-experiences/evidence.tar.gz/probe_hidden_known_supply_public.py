pytest_plugins = ['tests.life.conftest']

from agentsociety2.society import DirectToolCall
from tests.life.conftest import context, stage_day_plan
from tests.life.test_commerce import _stage_open
from worldmock.footprints.models import EventDraft
from worldmock.life.discovery import supply_row
from worldmock.life.models import PurchaseItem, PurchaseOrderRequest


def test_existing_unpresented_local_supply_through_decision(engine_factory):
    engine = engine_factory()
    _stage_open(engine)
    staged = engine.state.model_copy(deep=True)
    staged.agents[1] = staged.agents[1].model_copy(update={'location_id': 'market'}, deep=True)
    staged.version += 1
    engine.store.commit(staged.model_dump(mode='json'), [EventDraft(
        event_type='environment_event', occurred_at=staged.current_time,
        visibility='system', source_kind='scenario', data={'kind': 'probe_at_market'})])
    engine.state = staged
    stage_day_plan(engine)
    ctx = context(engine, 'probe-hidden-market')
    engine.begin_decision_round([ctx])
    observation = engine.observe(ctx)
    shown = set(engine._pending_visible_supplies[1])
    discovery = engine._discovery_context(engine.state.agents[1])
    candidates = [row for item in engine.scenario.supplies if item.location_id == 'market'
                  for row in [supply_row(discovery, item)]
                  if row['supply_id'] not in shown and row['purchase_allowed']
                  and row['pickup_allowed'] and row['purchase_price_fen'] <= engine.state.accounts['agent:1']]
    assert candidates, 'No purchasable unpresented local supply available in this snapshot'
    chosen = candidates[0]
    print('shown=', len(shown), 'eligible_unshown=', len(candidates))
    request = PurchaseOrderRequest(items=(PurchaseItem(
        supply_id=chosen['supply_id'], quantity=1, price_version=chosen['price_version']),),
        fulfillment='pickup', destination_id='market')
    before = (engine.state.accounts['agent:1'], engine.state.supply_stock[chosen['supply_id']])
    engine.submit_action(DirectToolCall(ctx, 'probe-purchase-hidden', 'purchase', request))
    result = engine.commit_decision_round('probe-hidden-market')[0]
    after = (engine.state.accounts['agent:1'], engine.state.supply_stock[chosen['supply_id']])
    print('result=', result.status.value, result.error_code, 'balance_stock_before_after=', before, after)
