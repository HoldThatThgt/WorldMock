from tests.footprints.test_quality import _event, _manifest
from worldmock.footprints.quality import build_quality_report

rows = [
    _event(1, 'environment_event', agent_id=1, occurred_at=110,
           data={'kind': 'body_settlement', 'interval_start': 100, 'interval_end': 110}),
    _event(2, 'environment_event', agent_id=1, occurred_at=115,
           data={'kind': 'body_settlement', 'interval_start': 105, 'interval_end': 115}),
    _event(3, 'environment_event', agent_id=2, occurred_at=115,
           data={'kind': 'body_settlement', 'interval_start': 100, 'interval_end': 115}),
]
report = build_quality_report(rows, [], _manifest(start=100, end=120))
print(report['activities']['person_elapsed_seconds_by_agent'])
