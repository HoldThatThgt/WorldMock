import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/worldmock-bob-experiences-worktree-9FSF7k')
evidence = Path('/tmp/worldmock-bob-experiences-evidence')
path = 'src/worldmock/footprints/quality.py'
source = root / path
old = 'total += max(0, end - max(start, previous_end))'
new = 'total += max(0, end - start)'
original = source.read_text()
assert original.count(old) == 1
source.write_text(original.replace(old, new, 1))
(evidence / 'quality_person_time_add_overlap.patch').write_text(subprocess.run(
    ['git', 'diff', '--', path], cwd=root, capture_output=True, text=True, check=True).stdout)
python = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
command = [python, '-m', 'pytest', '-q', 'tests/footprints/test_quality.py', 'tests/footprints/test_export.py']
env = os.environ.copy()
env.update(PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2',
           AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='http://127.0.0.1:9',
           MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
           LITELLM_LOCAL_MODEL_COST_MAP='True')
proc = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=180)
(evidence / 'quality_person_time_add_overlap.log').write_text(proc.stdout + proc.stderr)
results = json.loads((evidence / 'results.json').read_text())
results.append({'name': 'quality_person_time_add_overlap', 'spec': 'SPEC:41-42',
                'path': path, 'command': command, 'exit_code': proc.returncode,
                'log_tail': '\n'.join((proc.stdout + proc.stderr).splitlines()[-10:])})
subprocess.run(['git', 'restore', '--source=HEAD', '--', path], cwd=root, check=True)
clean = subprocess.run(['git', 'diff', '--exit-code'], cwd=root).returncode == 0 and not subprocess.run(
    ['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root,
    capture_output=True, text=True, check=True).stdout
results[-1]['clean_restoration'] = clean
(evidence / 'results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False) + '\n')
print(proc.stdout + proc.stderr)
print('restored', clean)
assert clean
