import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/worldmock-bob-experiences-recheck-QFVDyL')
evidence = Path('/tmp/worldmock-bob-experiences-evidence')
python = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
env = os.environ.copy()
env.update(PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2',
           AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='http://127.0.0.1:9',
           MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
           LITELLM_LOCAL_MODEL_COST_MAP='True')
mutants = [
    ('recent_oldest_five', 'src/worldmock/footprints/experiences.py',
     ['tests/footprints/test_verified_experiences.py']),
    ('person_time_add_overlap', 'src/worldmock/evaluation/behavior_metrics.py',
     ['tests/evaluation/test_behavior_metrics.py']),
    ('quality_person_time_add_overlap', 'src/worldmock/footprints/quality.py',
     ['tests/footprints/test_quality.py', 'tests/footprints/test_export.py']),
    ('purchase_known_hidden', 'src/worldmock/life/storefront_runtime.py',
     ['tests/life/test_engine_branch_coverage.py::test_purchase_rejects_invisible_product']),
]
results = []
for name, path, tests in mutants:
    patch = evidence / f'{name}.patch'
    expected = patch.read_bytes()
    subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True)
    actual = subprocess.run(['git', 'diff', '--', path], cwd=root,
                            capture_output=True, check=True).stdout
    if actual != expected:
        raise RuntimeError(f'{name}: applied diff is not byte-identical to original patch')
    command = [python, '-m', 'pytest', '-q', *tests]
    proc = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=180)
    log = proc.stdout + proc.stderr
    (evidence / f'recheck-{name}.log').write_text(log)
    subprocess.run(['git', 'restore', '--source=HEAD', '--', path], cwd=root, check=True)
    clean_diff = subprocess.run(['git', 'diff', '--exit-code'], cwd=root, capture_output=True)
    status = subprocess.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'],
                            cwd=root, capture_output=True, text=True, check=True)
    clean = clean_diff.returncode == 0 and not status.stdout
    results.append({'name': name, 'patch_sha256': hashlib.sha256(expected).hexdigest(),
                    'identical_patch': True, 'command': command, 'exit_code': proc.returncode,
                    'log_tail': '\n'.join(log.splitlines()[-15:]), 'restored_clean': clean})
    (evidence / 'recheck-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    print(name, proc.returncode, 'restored', clean, flush=True)
    if not clean:
        raise RuntimeError(f'{name}: unclean restore')
