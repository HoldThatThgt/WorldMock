import os
import subprocess
from pathlib import Path

root = Path('/tmp/worldmock-bob-experiences-worktree-9FSF7k')
evidence = Path('/tmp/worldmock-bob-experiences-evidence')
source = root / 'src/worldmock/life/storefront_runtime.py'
old = 'effective = set(projection.visible_supplies(state, agent, self.scenario))'
new = ('effective = set(projection.visible_supplies(state, agent, self.scenario)) | '
       '{item.supply_id for item in request.items if item.supply_id in self.rules.supplies}')
original = source.read_text()
assert original.count(old) == 1
source.write_text(original.replace(old, new, 1))
(evidence / 'purchase_known_hidden.patch').write_text(subprocess.run(
    ['git', 'diff', '--', 'src/worldmock/life/storefront_runtime.py'], cwd=root,
    capture_output=True, text=True, check=True).stdout)
env = os.environ.copy()
env.update(PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2',
           AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='http://127.0.0.1:9',
           MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
           LITELLM_LOCAL_MODEL_COST_MAP='True')
python = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
for name, tests in [
    ('purchase_known_hidden', ['tests/life/test_engine_branch_coverage.py::test_purchase_rejects_invisible_product']),
    ('purchase_known_hidden_probe', [str(evidence / 'probe_hidden_known_supply.py')]),
]:
    proc = subprocess.run([python, '-m', 'pytest', '-q', '-s', *tests], cwd=root, env=env,
                          capture_output=True, text=True, timeout=180)
    (evidence / f'{name}.log').write_text(proc.stdout + proc.stderr)
    print(name, proc.returncode, '\n'.join((proc.stdout + proc.stderr).splitlines()[-4:]))
subprocess.run(['git', 'restore', '--source=HEAD', '--', 'src/worldmock/life/storefront_runtime.py'],
               cwd=root, check=True)
assert subprocess.run(['git', 'diff', '--exit-code'], cwd=root).returncode == 0
assert not subprocess.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'],
                          cwd=root, check=True, capture_output=True, text=True).stdout
print('restored clean')
