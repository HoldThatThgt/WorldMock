pytest_plugins = ['tests.life.conftest']
from types import SimpleNamespace

from tests.life.test_commerce import _stage_open
from tests.life.test_dayrun_restaurants import RESTAURANT, SUPPLY
from worldmock.errors import BusinessRuleError
from worldmock.life.models import PurchaseItem, PurchaseOrderRequest
from worldmock.life.projection import visible_supplies


def test_existing_local_supply_requires_presentation(engine_factory):
    engine = engine_factory()
    _stage_open(engine)
    agent = engine.state.agents[1].model_copy(update={'location_id': RESTAURANT}, deep=True)
    state = engine.state.model_copy(deep=True)
    state.agents[1] = agent
    assert SUPPLY not in visible_supplies(state, agent, engine.scenario)
    quote = state.supply_quotes[SUPPLY]
    request = PurchaseOrderRequest(
        items=(PurchaseItem(supply_id=SUPPLY, quantity=1, price_version=quote.price_version),),
        fulfillment='pickup', destination_id=RESTAURANT)
    try:
        changed, result = engine._purchase(state, SimpleNamespace(agent_id=1, action_id='probe'), request)
    except BusinessRuleError as error:
        print('probe_result=REJECTED', str(error))
    else:
        print('probe_result=ACCEPTED', result.status.value, changed.supply_stock[SUPPLY])
