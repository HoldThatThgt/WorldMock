from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/worldmock-bob-experiences-worktree-9FSF7k')
evidence = Path('/tmp/worldmock-bob-experiences-evidence')
python = '/Users/atishoo/.codex/worktrees/dayrun-behavior/WorldMock/.venv/bin/python'
env = os.environ.copy()
env.update(PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2',
           AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='http://127.0.0.1:9',
           MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
           LITELLM_LOCAL_MODEL_COST_MAP='True')
mutants = [
    ('wait_relief', 'src/worldmock/life/body.py',
     '    if relief_per_hour:\n',
     '    if kind == ActivityKind.WAIT:\n        relief_per_hour = 0.5\n    if relief_per_hour:\n',
     ['tests/life/test_wait_passive_entertainment.py'], 'SPEC:35-39'),
    ('podcast_early_reveal', 'src/worldmock/life/content.py',
     'visible = [cue for cue in cues if start < cue.end_seconds <= stop]',
     'visible = [cue for cue in cues if cue.start_seconds < stop and cue.end_seconds > start]',
     ['tests/life/test_dayrun_podcast_playback.py'], 'SPEC:51-53'),
    ('purchase_hidden_supply', 'src/worldmock/life/storefront_runtime.py',
     'if any(item.supply_id not in effective for item in request.items):',
     'if False and any(item.supply_id not in effective for item in request.items):',
     ['tests/life/test_engine_branch_coverage.py::test_purchase_rejects_invisible_product'],
     'SPEC:136-139'),
    ('consume_cumulative_as_increment', 'src/worldmock/life/activity_evidence.py',
     '- before_consumed.get(item.product_id, 0.0)),',
     '- 0.0),',
     ['tests/integration/test_meal_checkpoint.py', 'tests/footprints/test_verified_experiences.py'],
     'SPEC:141-143,159-165'),
    ('recent_oldest_five', 'src/worldmock/footprints/experiences.py',
     '    return facts[-5:]\n', '    return facts[:5]\n',
     ['tests/footprints/test_verified_experiences.py'], 'SPEC:149-153'),
    ('export_only_five', 'src/worldmock/footprints/export.py',
     'for fact in project_verified_experiences(events, agent_id=agent_id, cutoff_seq=cutoff)]',
     'for fact in project_verified_experiences(events, agent_id=agent_id, cutoff_seq=cutoff)[-5:]]',
     ['tests/footprints/test_export.py'], 'SPEC:153-154'),
    ('person_time_add_overlap', 'src/worldmock/evaluation/behavior_metrics.py',
     'total += max(0.0, end - max(start, previous_end))',
     'total += max(0.0, end - start)',
     ['tests/evaluation/test_behavior_metrics.py'], 'SPEC:41-42'),
    ('model_source_accepted', 'src/worldmock/footprints/experiences.py',
     'if event.source_kind != "environment" or event.visibility != "agent":',
     'if event.source_kind != "environment" and event.visibility != "agent":',
     ['tests/footprints/test_verified_experiences.py'], 'SPEC:149-154'),
]
(evidence / 'declared-mutants.json').write_text(json.dumps([
    {'name': name, 'path': path, 'before': before, 'after': after, 'spec': spec,
     'command': [python, '-m', 'pytest', '-q', *tests]}
    for name, path, before, after, tests, spec in mutants
], indent=2, ensure_ascii=False) + '\n')
results = []
for name, path, before, after, tests, spec in mutants:
    source = root / path
    original = source.read_text()
    if original.count(before) != 1:
        raise RuntimeError(f'{name}: expected exactly one source occurrence, found {original.count(before)}')
    source.write_text(original.replace(before, after, 1))
    diff = subprocess.run(['git', 'diff', '--', path], cwd=root, capture_output=True, text=True, check=True)
    (evidence / f'{name}.patch').write_text(diff.stdout)
    command = [python, '-m', 'pytest', '-q', *tests]
    try:
        proc = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=180)
        log = proc.stdout + proc.stderr
        code = proc.returncode
    except subprocess.TimeoutExpired as error:
        log = (error.stdout or b'').decode(errors='replace') + (error.stderr or b'').decode(errors='replace')
        code = 'timeout'
    (evidence / f'{name}.log').write_text(log)
    subprocess.run(['git', 'restore', '--source=HEAD', '--', path], cwd=root, check=True)
    clean_diff = subprocess.run(['git', 'diff', '--exit-code'], cwd=root, capture_output=True, text=True)
    status = subprocess.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'],
                            cwd=root, capture_output=True, text=True, check=True)
    clean = clean_diff.returncode == 0 and not status.stdout
    results.append({'name': name, 'spec': spec, 'path': path, 'command': command,
                    'exit_code': code, 'clean_restoration': clean,
                    'log_tail': '\n'.join(log.splitlines()[-16:])})
    (evidence / 'results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False) + '\n')
    print(f'{name}: exit={code}, restored={clean}', flush=True)
    if not clean:
        raise RuntimeError(f'{name}: restoration failed: {status.stdout} {clean_diff.stdout}')
