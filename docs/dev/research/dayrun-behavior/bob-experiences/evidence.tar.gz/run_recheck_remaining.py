import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/worldmock-bob-experiences-recheck-QFVDyL')
evidence = Path('/tmp/worldmock-bob-experiences-evidence')
env = os.environ.copy()
env.update(PYTHONPATH='src:.:vendor/agentsociety2/packages/agentsociety2',
           AGENTSOCIETY_LLM_API_KEY='test-only', AGENTSOCIETY_LLM_API_BASE='http://127.0.0.1:9',
           MEM0_TELEMETRY='False', ANONYMIZED_TELEMETRY='False',
           LITELLM_LOCAL_MODEL_COST_MAP='True')
original = {row['name']: row for row in json.loads((evidence / 'declared-mutants.json').read_text())}
names = ('wait_relief', 'podcast_early_reveal', 'purchase_hidden_supply',
         'consume_cumulative_as_increment', 'export_only_five', 'model_source_accepted')
results = []
for name in names:
    row = original[name]
    patch = evidence / f'{name}.patch'
    expected = patch.read_bytes()
    subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True)
    actual = subprocess.run(['git', 'diff', '--', row['path']], cwd=root,
                            check=True, capture_output=True).stdout
    if actual != expected:
        raise RuntimeError(f'{name}: applied diff is not byte-identical to original patch')
    proc = subprocess.run(row['command'], cwd=root, env=env,
                          capture_output=True, text=True, timeout=180)
    log = proc.stdout + proc.stderr
    (evidence / f'recheck-{name}.log').write_text(log)
    subprocess.run(['git', 'restore', '--source=HEAD', '--', row['path']], cwd=root, check=True)
    clean = subprocess.run(['git', 'diff', '--exit-code'], cwd=root, capture_output=True).returncode == 0
    status = subprocess.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root,
                            capture_output=True, text=True, check=True).stdout
    clean = clean and not status
    results.append({'name': name, 'patch_sha256': hashlib.sha256(expected).hexdigest(),
                    'identical_patch': True, 'command': row['command'], 'exit_code': proc.returncode,
                    'log_tail': '\n'.join(log.splitlines()[-15:]), 'restored_clean': clean})
    (evidence / 'recheck-remaining-results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False) + '\n')
    print(name, proc.returncode, 'restored', clean, flush=True)
    if not clean:
        raise RuntimeError(f'{name}: unclean restore')
